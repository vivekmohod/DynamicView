package com.klouddata.dynamicview.listener;

import android.view.View;

import com.klouddata.dynamicview.entitytypes_form.Field;

/**
 * Created by vivekm on 6/15/2016.
 */
public interface CheckBoxChangeListener {

    void getSelectedValue(Field field, View v);
}
