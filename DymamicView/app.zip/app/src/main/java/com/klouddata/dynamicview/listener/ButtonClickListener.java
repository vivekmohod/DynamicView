package com.klouddata.dynamicview.listener;

import android.view.View;

/**
 * Created by vivekm on 6/15/2016.
 */
public interface ButtonClickListener {

    public void onClick(View v);
}
