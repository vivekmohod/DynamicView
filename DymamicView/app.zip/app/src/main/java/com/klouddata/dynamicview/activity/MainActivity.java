package com.klouddata.dynamicview.activity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.klouddata.dymamicview.R;
import com.klouddata.dynamicview.entitytypes_form.DataType;
import com.klouddata.dynamicview.entitytypes_form.Field;
import com.klouddata.dynamicview.entitytypes_form.FieldType;
import com.klouddata.dynamicview.listener.ButtonClickListener;
import com.klouddata.dynamicview.listener.CheckBoxChangeListener;
import com.klouddata.dynamicview.listener.DatePickerListener;
import com.klouddata.dynamicview.listener.EditTextChangeListener;
import com.klouddata.dynamicview.listener.OnObservableChangeListener;
import com.klouddata.dynamicview.listener.TimePickerListener;
import com.klouddata.dynamicview.ui_generator.LoadableImageView;
import com.klouddata.dynamicview.ui_generator.UIBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

import static android.widget.Toast.makeText;


public class MainActivity extends BaseActivity {
    private OnObservableChangeListener listener;
    private LinearLayout layout;
    private LayoutInflater inflater;
    private ScrollView scrollView;
    private Context context;
    private LoadableImageView bannerLoadableImageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.MATCH_PARENT));
        layout = new LinearLayout(this);
        layout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        layout.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(layout);
        inflater = (LayoutInflater)this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        addSpinnerToLayout();
        addRadioButtonToLayout();
        addCheckBoxToLayout();
        //addLabelToLayout();
        addButtonToLayout();
        addEditTextToLayout();
        downloadImage();
        addDatePicker();
        addTimePicker();
        setContentView(scrollView);
      //  setContentView(R.layout.activity_main);
       /* Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }



    private void addDatePicker() {
        final Field field = getFieldJSON();
        View view = null;
        DatePickerListener listener = new DatePickerListener() {
            @Override
            public void getDate(Field field) {
                Toast.makeText(context, "Date :" + field.getDataObject(), Toast.LENGTH_SHORT).show();
            }
        };
        view = UIBuilder.getDatePicker(inflater, this, field, listener);
        layout.addView(view);
    }

    private void addTimePicker() {
        final Field field = getFieldJSON();
        View view = null;
        TimePickerListener listener = new TimePickerListener() {
            @Override
            public void getTime(Field field) {
                Toast.makeText(context, "Time :" + field.getDataObject(), Toast.LENGTH_SHORT).show();
            }
        };
        view = UIBuilder.getTimePicker(inflater, this, field, listener);
        layout.addView(view);
    }

    private void downloadImage() {
        bannerLoadableImageView = new LoadableImageView(context);
        bannerLoadableImageView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 120));
        bannerLoadableImageView.loadImageFromURL(
                "http://ibhakti.com/temple/resources/images/store/rudraksh_store_banner.jpg", 0, false, false);
        layout.addView(bannerLoadableImageView);
    }

    private void addEditTextToLayout() {
        final Field field = getFieldJSON();
        EditTextChangeListener listener = new EditTextChangeListener() {
            @Override
            public void getEnteredText(Field field1, View view) {
                Toast.makeText(context, ""+field1.getDataObject(), Toast.LENGTH_SHORT).show();
                if (field1.getDataObject() != null)
                    view.setVisibility(View.VISIBLE);
            }
        };
        View view = null;
        view = UIBuilder.getEditText(field, inflater, this, listener);
        layout.addView(view);
    }

    private void addButtonToLayout() {
        Field field = getFieldJSON();
        ButtonClickListener listener = new ButtonClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getBaseContext(), "Button is clicked", Toast.LENGTH_SHORT).show();
            }
        };

        View view = null;
        view = UIBuilder.getButton(field, inflater, this, listener);
        layout.addView(view);
    }

    private void addLabelToLayout() {
        Field field = getFieldJSON();
        View view = null;
        view = UIBuilder.getLabel(field, inflater, this);
        layout.addView(view);
    }

    private void addCheckBoxToLayout() {
        Field field = getFieldJSON();
        CheckBoxChangeListener listener = new CheckBoxChangeListener() {
            @Override
            public void getSelectedValue(Field field, View v) {
               Toast.makeText(getBaseContext(), "value : " + field.getDataObject(), Toast.LENGTH_SHORT).show();
            }
        };
        View view = null;
        view = UIBuilder.getCheckBox(field, inflater, this, listener);
        layout.addView(view);
    }

    private void addRadioButtonToLayout() {
        Field field = getFieldJSON();
        CheckBoxChangeListener listener = new CheckBoxChangeListener() {
            @Override
            public void getSelectedValue(Field field, View v) {
                Toast.makeText(getBaseContext(), "value : " + field.getDataObject(), Toast.LENGTH_SHORT).show();
            }
        };
        View view = null;
        view = UIBuilder.getRadio(field, inflater, this, listener);
        layout.addView(view);
    }

    private Field getFieldJSON() {
        Field field = new Field();
        try {
            JSONObject obj = new JSONObject(loadJSONFromAsset());

            JSONObject object = obj.getJSONObject("view");

            field.setFieldType(FieldType.getFieldType(object.getString("fieldType")));
            field.setDataType(DataType.getDataType(object.getString("dataType")));
            field.setPrimaryLabel(object.getString("primaryLabel"));
            field.setSecounderyLabel(object.getString("secounderyLabel"));
            field.setIsMandatory(object.getBoolean("isMandatory"));
            field.setDropDownSelectedItemPosition(object.getInt("dropDownSelectedItemPosition"));
            field.setHint(object.getString("hint"));
            field.setDependentDesc(object.getString("dependentDesc"));
            field.setDependentFields(object.getString("dependentFields"));
            field.setDataObject(object.getString("dataObject"));
            field.setVisibility(object.getBoolean("visibility"));
            field.setLines(object.getInt("lines"));

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return field;
    }


    private void addSpinnerToLayout() {
        Field field = getFieldJSON();
        View view = null;

        listener = new OnObservableChangeListener() {
            @Override
            public void onDependentVisible(Field field, View v, int rowId, int visibility) {
                makeText(MainActivity.this, " " + field.getDataObject() + ", " + rowId, Toast.LENGTH_LONG).show();
                if (field.getDataObject().equalsIgnoreCase(" Select")) {
                    v.setVisibility(View.VISIBLE);
                    ((TextView)v).setText("Enter Number");
                } else   v.setVisibility(View.GONE);
            }

            @Override
            public void onDependentInitialized(Field field, View v, int rowId, int visibility) {
                makeText(MainActivity.this, " " + field.getDataObject(), Toast.LENGTH_LONG).show();
            }
        };

     /*   field.setPrimaryLabel("Compulsory Field");
       // field.setSecounderyLabel("Select Number");
        field.setIsMandatory(true);
        field.setDropDownSelectedItemPosition(5);
        field.setHint("One, Select, Two, Three, Four, Five, Six, Seven");
        field.setDependentDesc("Not");
        field.setDependentFields("Two");
        field.setDataObject("Two");*/
        if (field.getFieldType().equals(FieldType.DROP_DOWN)) {
            view = UIBuilder.getDropDownView(inflater, this, field, listener, 5);
        }
        view.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        layout.addView(view);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {
            InputStream is = this.getAssets().open("json.txt");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

}
