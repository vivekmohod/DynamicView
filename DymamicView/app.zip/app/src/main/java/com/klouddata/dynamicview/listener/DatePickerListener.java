package com.klouddata.dynamicview.listener;

import com.klouddata.dynamicview.entitytypes_form.Field;

/**
 * Created by vivekm on 6/20/2016.
 */
public interface DatePickerListener {

    public void getDate(Field field);
}
